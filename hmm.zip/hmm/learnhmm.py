from __future__ import print_function
import numpy as np
import sys
if __name__ == '__main__' :
    train_input = sys.argv[1]
    index_to_word = sys.argv[2]
    index_to_tag = sys.argv[3]
    hmmprior = sys.argv[4]
    hmmemit = sys.argv[5]
    hmmtrans = sys.argv[6]


def train_parse(file):
    rows = []
    with open(file) as fp:
        line = fp.readline()
        while line:
            rows.append(line.split())
            line = fp.readline()
    return rows


def something_to_index(filename):
    d = {}
    a= []
    count = 1 
    with open(filename) as fp:
        line = fp.readline()
        while line:
            a.append(line.split()[-1])
            d[line.split()[-1]] = count
            count = count + 1
            line = fp.readline()
    return a,d


def preprocess(word_to_index,tag_to_index,rows):
    word = []
    tag = []
    word_tag = []
    for i in range(len(rows)):
        w = []
        t = []
        w_t = []
        for j in range(len(rows[i])):
            token = rows[i][j].split('_')
            w.append(word_to_index[token[0]])
            t.append(tag_to_index[token[1]])
            w_t.append(str(word_to_index[token[0]])+'_'+str(tag_to_index[token[1]]))
        word.append(w)
        tag.append(t)
        word_tag.append(w_t)
    return word,tag,word_tag


def prior(rows):
    
        first_tag = []
        for i in range(len(rows)):
            first_tag.append(rows[i][0].split('_')[-1])
        
        first_tag_count = []
        for i in tags:  
            first_tag_count.append(first_tag.count(i))   
        first_tag_count = [x+1 for x in first_tag_count]
        pi = [x/sum(first_tag_count ) for x in first_tag_count]
        
        return pi


def transition(tags,tags_matrix):
    
    alpha = []
    for i in range(len(tags_matrix)):
        a = []
        for j in range(len(tags_matrix[i])-1):
            a.append(str(tags_matrix[i][j])+'_'+str(tags_matrix[i][j+1]))
        alpha.append(a)

    d = {}
    for j in range(len(alpha)):
        for i in alpha[j]:
            token = i.split('_')
            p = token[0]
            c = token[1]
            if p not in d:
                d[p] = {}
                d[p][c] = 1
            else:
                if c not in d[p]:
                    d[p][c] = 1
                else:
                    d[p][c] = d[p][c] + 1   
    
    count_transition = np.zeros((len(tags),len(tags)))
    ones = np.ones(count_transition.shape)
    
    for key in d:
        for k in d[key]:
            count_transition[int(key)-1][int(k)-1] = d[key][k]
    
    new_count = count_transition + ones
    
    for l in range(len(new_count)):
        new_count[l] = new_count[l]/sum(new_count[l]) 
    
    return new_count


def emission(tags,words,words_and_tags_matrix):
        d = {}
        for j in range(len(words_and_tags_matrix)):
            for i in words_and_tags_matrix[j]:
                token = i.split('_')
                c = token[0]
                p = token[1]
                if p not in d:
                    d[p] = {}
                    d[p][c] = 1
                else:
                    if c not in d[p]:
                        d[p][c] = 1
                    else:
                        d[p][c] = d[p][c] + 1  

        count_emission = np.zeros((len(tags),len(words)))
        ones = np.ones(count_emission.shape)
        for key in d:
                for k in d[key]:
                    count_emission[int(key)-1][int(k)-1] = d[key][k]

        new_count = count_emission + ones
        for l in range(len(new_count)):
                new_count[l] = new_count[l]/sum(new_count[l]) 
        return new_count


rows = train_parse(train_input)
tags,tag_to_index = something_to_index(index_to_tag)
words,word_to_index = something_to_index(index_to_word)
prior_matrix = prior(rows)
words_matrix,tags_matrix,words_and_tags_matrix = preprocess(word_to_index,tag_to_index,rows)
transition_matrix = transition(tags,tags_matrix)
emission_matrix = emission(tags,words,words_and_tags_matrix)



with open(hmmprior, 'w') as file:
    for i in range(len(prior_matrix)):
        file.write(str(prior_matrix[i])+'\n')

with open(hmmtrans, 'w') as file:
    for i in range(len(transition_matrix)):
        s = ' '
        l = [str(x) for x in transition_matrix[i]]
        s = s.join(l)
        file.write(s+'\n')

with open(hmmemit, 'w') as file:
    for i in range(len(emission_matrix)):
        s = ' '
        l = [str(x) for x in emission_matrix[i]]
        s = s.join(l)
        file.write(s+'\n')

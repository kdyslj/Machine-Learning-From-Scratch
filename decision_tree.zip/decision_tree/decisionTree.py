from __future__ import print_function
import sys
if __name__ == '__main__' :
    train_file = sys.argv[1]
    test_file = sys.argv[2]
    max_depth = sys.argv[3]
    train_labels = sys.argv[4]
    test_labels = sys.argv[5]
    metrics = sys.argv[6]
    
import csv
import numpy as np
import math

def create_dict(narray):
    data = {}
    for i in range(narray.shape[-1]):
        data[narray[0][i]] = []
        for j in range(1,narray.shape[0]):
            data[narray[0][i]].append(narray[j][i])
        data[narray[0][i]] = np.array(data[narray[0][i]] )
    return data

def entropy(data):
    target = list(data.keys())[-1]   
    entropy = 0
    values,counts = np.unique(data[target],return_counts=True)
    for i in range(len(values)):
        p = counts[i]/np.sum(counts)   
        try:
            entropy = entropy + (-p*math.log2(p))              
        except:
            entropy = entropy + 0
    return entropy

def conditional_entropy(data,feature):
    
    target = list(data.keys())[-1]   
    target_variables,target_counts = np.unique(data[target],return_counts=True) 
    variables = np.unique(data[feature])   
    target_col = data[target]
    feature_col = data[feature]
    conditional_entropy = 0
    
    for variable in variables:
        entropy = 0
        new_target_col=[]
        
        for i in range(len(feature_col)):
            if feature_col[i] == variable:
                new_target_col.append(target_col[i])
        for target_variable in target_variables:
            n=0
            for j in range(len(new_target_col)):
                if new_target_col[j] == target_variable:
                    n=n+1
            
            try:
                p = n/len(np.where(data[feature]==variable)[0])
                entropy = entropy + (-p*math.log2(p))
            except:
                p= 0
                entropy = entropy + 0
            p2 = len(np.where(data[feature]==variable)[0])/len(data[feature])
            conditional_entropy = conditional_entropy + (p2*entropy)

    return conditional_entropy

def mutual_information(a,b):
    return a - b

def best_feature_split(data):
    MI = []
    for key in list(data.keys())[:-1]:
        MI.append(mutual_information(entropy(data),conditional_entropy(data,key)))
    return list(data.keys())[:-1][np.argmax(MI)]


def get_subtree(data,feature,value):
    feature_col = data[feature]
 
    feature_col = np.insert(feature_col,0,feature)
    l=[]
    m=[]
    for key in data:
        if key!=feature:
            l.append([key]+list(data[key]))
    
    l=np.array(l).T

    for i in range(1,len(feature_col)):
        if feature_col[i] == value:
            m.append(l[i])
    m = np.array(m)
    key_list = [i for i in list(data.keys()) if i!=feature]
    
    m=np.insert(m,0,key_list,axis=0)
    return create_dict(m)

pig=[]

def buildtree(data,max_depth,tree=None):
    
    depth = max_depth
    target = list(dataset.keys())[-1]    
    t_val,c = np.unique(dataset[target],return_counts=True)
    if len(pig)==0:
       pig.append(['[',str(c[0]),str(t_val[0]),'/',str(c[1]),str(t_val[1]),']']) 

    
      
    if max_depth == 0:
        target_value,counts = np.unique(data[target],return_counts=True)
        return target_value[np.argmax(counts)]
    
    else:
        node = best_feature_split(data)
    
        feature_values = np.unique(data[node])
        if tree is None:                    
           tree={}
           tree[node] = {}

        
        for value in feature_values:
           
            subtree = get_subtree(data,node,value)
            target_value,counts = np.unique(subtree[target],return_counts=True)
            if len(counts)>1:
               pig.append([str(depth),str(node),' = ', str(value),': [',str(counts[0]),' '+str(target_value[0]),'/'+str(counts[1]),' ',str(target_value[1]),']'])
           
            else:
               if target_value[0] == t_val[0]:
                  pig.append([str(depth),str(node),' = '+ str(value),': ['+str(counts[0]),' '+str(target_value[0]),'/0 ',str(t_val[1]),']'])
               else:
                  pig.append([str(depth),str(node),' = ', str(value),': ['+str(counts[0]),' ',str(target_value[0]),'/0 ',str(t_val[0]),']'])
            if len(subtree)==1:         
                
                tree[node][value]= target_value[np.argmax(counts)]

            else:
      
                if len(counts) == 1 or 0 in counts:
                    tree[node][value] = target_value[0] 
                                                   
                else:        
                    tree[node][value] = buildtree(subtree,depth-1) 
       
    return tree


def prediction(test,tree):
    
    if type(tree) is dict:
        for key in tree.keys():        
            value = test[key]
            tree = tree[key][value]
            predict = 0
            if type(tree) is dict:            
                predict = prediction(test, tree)                    
            else:
                predict = tree
                break;                                   
        return predict
    else:
        return tree

def error(array1,array2):
    error=0
    for i in range(len(array1)):
        if array1[i]!=array2[i]:
            error=error+1
    return error/(len(array1))


rows=[]
with open(train_file) as tsvfile:
    reader = csv.reader(tsvfile, delimiter='\t')
    for row in reader:
        rows.append(row)
dataset_train = np.array(rows)


dataset = create_dict(dataset_train)

tree = buildtree(dataset,int(max_depth))


for i in range(len(pig)):
    if i==0:
        print(' '.join(pig[i]))
    else:
            l=int(max_depth)-int(pig[i][0])+1
            print('| '*l+' '.join(pig[i][1:]))

y_pred=[]
y_true=[]
for j in range(1,len(dataset_train)):
    d={}
    for i in range(dataset_train.shape[-1]):
         d[dataset_train[0][i]] = dataset_train[j][i]
    try:        
         y_pred.append(prediction(d,tree)) 
         y_true.append(dataset_train[j][-1])   
    except:
         continue



error_train = error(y_true,y_pred)


rows_test=[]
with open(test_file) as tsvfile:
     reader = csv.reader(tsvfile, delimiter='\t')
     for row in reader:
        rows_test.append(row)
dataset_test = np.array(rows_test)


y_pred_test=[]
y_true_test=[]
for j in range(1,len(dataset_test)):
      d_test={}
      for i in range(dataset_test.shape[-1]):
           d_test[dataset_test[0][i]] = dataset_test[j][i]
      try:        
           y_pred_test.append(prediction(d_test,tree)) 
           y_true_test.append(dataset_test[j][-1])   
      except:
           continue


error_test = error(y_true_test,y_pred_test)

with open(train_labels, 'w') as w:
     for i in range(len(y_pred)):
         w.write(y_pred[i]+'\n')

with open(test_labels, 'w') as w:
     for i in range(len(y_pred_test)):
         w.write(y_pred_test[i]+'\n')

with open(metrics, 'w') as w:
	 w.write('error(train): '+str(error_train)+'\n')
	 w.write('error(test): ' +str(error_test))




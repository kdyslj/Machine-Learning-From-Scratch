from __future__ import print_function
import numpy as np
import sys
if __name__ == '__main__' :
    test_input = sys.argv[1]
    index_to_word = sys.argv[2]
    index_to_tag = sys.argv[3]
    hmmprior = sys.argv[4]
    hmmemit = sys.argv[5]
    hmmtrans = sys.argv[6]
    predicted_file = sys.argv[7]
    metrics = sys.argv[8]


def parse(file):
    rows = []
    with open(file) as fp:
        line = fp.readline()
        while line:
            rows.append(line.split())
            line = fp.readline()
    return rows


def something_to_index(filename):
    s2i = {}
    i2s = {}
    a= []
    count = 1 
    with open(filename) as fp:
        line = fp.readline()
        while line:
            a.append(line.split()[-1])
            s2i[line.split()[-1]] = count
            i2s[count] = line.split()[-1]
            count = count + 1
            line = fp.readline()
    return a,s2i,i2s



def preprocess(word_to_index,tag_to_index,rows):
    word = []
    tag = []
    word_tag = []
    for i in range(len(rows)):
        w = []
        t = []
        w_t = []
        for j in range(len(rows[i])):
            token = rows[i][j].split('_')
            w.append(word_to_index[token[0]])
            t.append(tag_to_index[token[1]])
            w_t.append(str(word_to_index[token[0]])+'_'+str(tag_to_index[token[1]]))
        word.append(w)
        tag.append(t)
        word_tag.append(w_t)
    return word,tag,word_tag


def viterbi(seq,prior_matrix,transition_matrix,emission_matrix):
    w = np.zeros((len(prior_matrix),len(seq)))
    for i in range(len(w)):
        w[i][0] = np.log(prior_matrix[i]) + np.log(emission_matrix[i][seq[0]-1])
        #w[i][0] = prior_matrix[i]*emission_matrix[i][seq[0]-1]
        
    bp = []
    for k in range(1,len(seq)):
        b = []
        for i in range(len(w)):

            x = []
            arr = np.zeros(len(w))
            for j in range(len(w)):
                arr[j] = np.log(emission_matrix[i][seq[k]-1]) + np.log(transition_matrix[j][i]) + w[j][k-1]
                #arr[j] = emission_matrix[i][seq[k]-1]*transition_matrix[j][i]*w[j][k-1]
                x.append(arr[j])
            w[i][k] = max(arr)
            b.append(x.index(max(x)) )
        bp.append(b)
    
    tag=[]
    tag.append(np.argmax(w[:,-1])+1)
    c = np.argmax(w[:,-1])

    for i in range(len(bp)-1,-1,-1):
        tag.append(bp[i][c]+1)
        c = bp[i][c]
        
    tag = tag[::-1]
        
    tag_seq = []
    for i in range(len(seq)):
        tag_seq.append(index_to_word[seq[i]]+'_'+index_to_tag[tag[i]])
    return tag,tag_seq


test_rows = parse(test_input)
tags,tag_to_index,index_to_tag = something_to_index(index_to_tag)
words,word_to_index,index_to_word = something_to_index(index_to_word)
test_words_matrix,test_tags_matrix,test_words_and_tags_matrix = preprocess(word_to_index,tag_to_index,test_rows)
prior_matrix = np.loadtxt(hmmprior)
transition_matrix = np.loadtxt(hmmtrans)
emission_matrix = np.loadtxt(hmmemit)

predicted_seqs = []
predicted_tags = []
for i in range(len(test_words_matrix)):
    p_tags,p_seq = viterbi(test_words_matrix[i],prior_matrix,transition_matrix,emission_matrix)
    predicted_seqs.append(p_seq)
    predicted_tags.append(p_tags)


total = 0
error = 0
for i in range(len(test_tags_matrix)):
    total = total + len(test_tags_matrix[i])
    for j in range(len(test_tags_matrix[i])):
        if test_tags_matrix[i][j] != predicted_tags[i][j]:
            error = error + 1
accuracy = 1-error/total


with open(predicted_file, 'w') as file:
    for i in range(len(predicted_seqs)):
        s = ' '
        s = s.join(predicted_seqs[i])
        file.write(s+'\n')


with open(metrics, 'w') as file:
    file.write('Accuracy: '+str(accuracy)+'\n')
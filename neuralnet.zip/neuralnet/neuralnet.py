from __future__ import print_function
import sys
if __name__ == '__main__' :
    train_file = sys.argv[1]
    test_file = sys.argv[2]
    outfile1 = sys.argv[3]
    outfile2 = sys.argv[4]
    metrics = sys.argv[5]
    num_epoch = int(sys.argv[6])
    hidden_units = int(sys.argv[7])
    flag = int(sys.argv[8])
    lr = float(sys.argv[9])


import csv
import numpy as np


def parse_data(filename):
    rows=[]
    with open(filename) as tsvfile:
        reader = csv.reader(tsvfile, delimiter=',')
        for row in reader:
            rows.append(row)

        feat = []
        lab = []
        for i in range(len(rows)):
            lab.append(int(rows[i][0]))
            f= [float(i) for i in rows[i][1:]]
            feat.append([1]+f)
        return np.array(feat),np.array(lab)


def initialization(num_hidden,num_inputs,num_outputs,flag):
    if flag == 1:
        a = np.random.uniform(low=-0.1, high=0.1, size=(num_hidden,num_inputs))
        b = np.random.uniform(low=-0.1, high=0.1, size=(num_outputs,num_hidden+1))
        a[:,0] = 0
        b[:,0] = 0
    else:
        a = np.zeros((num_hidden,num_inputs))
        b = np.zeros((num_outputs,num_hidden+1))
    return a,b

def linear_forward(x,w):
    a = np.matmul(x,w.T).T
    return a

def sigmoid_forward(p):
    return 1/(1+np.exp(-p))

def softmax_forward(q):
    b = np.exp(q)
    return b/sum(b)

def cross_entropy_forward(y_true,y_pred):
    return  -np.log(y_pred[np.argmax(y_true)])

def nn_forward(feat,lab,alp,bet,flag):
    d = {}
    if flag == 1:
           a = linear_forward(feat,alp)
           a = np.insert(a,0,1)
           z = sigmoid_forward(a)
    else:
           a = linear_forward(feat,alp)
           z = sigmoid_forward(a)
           z = np.insert(z,0,1) 
    d['a'] = a
    d['z'] = z
    b = linear_forward(z,bet)
    d['b'] = b
    y_hat = softmax_forward(b)
    d['y_hat'] = y_hat
    J = cross_entropy_forward(lab,y_hat)
    d['J'] = J 
    return d

def cross_entropy_softmax_backward(y_true,y_pred):
    db = np.zeros((y_pred.shape))
    for i in range(len(y_pred)):
        for j in range(len(y_pred)):
            if i == j:
                db[i] = db[i] + (-y_true[j]*(1-y_pred[i]))
            else:
                db[i] = db[i] + (y_true[j]*y_pred[i])
    return db

def linear_backward(s,param, g_prev):
    g_param = np.matmul(g_prev.reshape(-1,1),s.reshape(1,-1))
    gs = np.matmul(param.T,g_prev)
    return g_param,gs

def sigmoid_backward(gz,a):
    return gz*a*(1-a)

def nn_backward(feat,lab,alp,bet,dic):
    g_b = cross_entropy_softmax_backward(lab,dic['y_hat'])
    gbeta,g_z = linear_backward(dic['z'], bet[:,1:], g_b)
    g_a = sigmoid_backward(g_z,dic['z'][1:])
    galpha,g_x = linear_backward(feat,alp, g_a)
    return galpha,gbeta

def sgd(feat,lab,test_feat,test_lab,num_hidden,epochs,lr,flag):
    num_inputs = feat.shape[1]
    num_outputs = len(np.unique(lab))
    y = np.zeros((len(lab), len(np.unique(lab))))
    y[np.arange(len(lab)), lab] = 1 
    y_test = np.zeros((len(test_lab), len(np.unique(test_lab))))
    y_test[np.arange(len(test_lab)), test_lab] = 1
    alpha,beta = initialization(num_hidden,num_inputs,num_outputs,flag)
    Train_Loss = []
    Test_Loss = []
    for i in range(epochs):
        for j in range(len(feat)):
            obj = nn_forward(feat[j],y[j],alpha,beta,flag)
            g_alpha,g_beta = nn_backward(feat[j],y[j],alpha,beta,obj)
            alpha = alpha - lr*g_alpha
            beta = beta - lr*g_beta

        tr_l = 0    
        for k in range(len(feat)):
            o = nn_forward(feat[k],y[k],alpha,beta,flag)
            tr_l = tr_l + o['J']
        Train_Loss.append(tr_l/len(feat))
        
        tst_l = 0
        for k in range(len(test_feat)):
            p = nn_forward(test_feat[k],y_test[k],alpha,beta,flag)
            tst_l = tst_l + p['J']
        Test_Loss.append(tst_l/len(test_feat))
        
    return alpha,beta,Train_Loss,Test_Loss

def prediction(feat,alp,bet,flag):
    
    lab_pred = []
    
    for i in range(len(feat)):
        if flag == 1:
           a = linear_forward(feat[i],alp)
           a = np.insert(a,0,1)
           z = sigmoid_forward(a)
        else:
           a = linear_forward(feat[i],alp)
           z = sigmoid_forward(a)
           z = np.insert(z,0,1) 
        b = linear_forward(z,bet)
        y_hat = softmax_forward(b)
        y_pr = np.argmax(y_hat)
        lab_pred.append(y_pr)
    return lab_pred

def error_stats(lab,lab_pred):
    error = 0
    for i in range(len(lab)):
        if lab_pred[i] != lab[i]:
            error = error+1
    return error/len(lab)


train_features,train_labels = parse_data(train_file)
test_features,test_labels = parse_data(test_file)
alpha1,beta1,loss1,loss2=sgd(train_features,train_labels,test_features,test_labels,hidden_units,num_epoch,lr,flag)


labels_pred = prediction(train_features,alpha1,beta1,flag)
labels_pred_test = prediction(test_features,alpha1,beta1,flag)

train_error = error_stats(train_labels,labels_pred)
test_error = error_stats(test_labels,labels_pred_test)

with open(outfile1, 'w') as w:
     for i in range(len(labels_pred)):
         w.write(str(labels_pred[i])+'\n')

with open(outfile2, 'w') as w:
     for i in range(len(labels_pred_test)):
         w.write(str(labels_pred_test[i])+'\n')

with open(metrics, 'w') as w:
     for i in range(len(loss1)):
         w.write('epoch='+str(i+1)+' crossentropy(train): '+str(loss1[i])+'\n')
         w.write('epoch='+str(i+1)+' crossentropy(test): '+str(loss2[i])+'\n')
     w.write('error(train): '+str(train_error)+'\n')
     w.write('error(test): ' +str(test_error))


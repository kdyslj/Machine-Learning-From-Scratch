from __future__ import print_function
from environment import MountainCar
import numpy as np
import sys
if __name__ == '__main__' :
    mode = sys.argv[1]
    weight_out = sys.argv[2]
    returns_out = sys.argv[3]
    episodes = int(sys.argv[4])
    max_iter = int(sys.argv[5])
    epsilon = float(sys.argv[6])
    gamma = float(sys.argv[7])
    lr = float(sys.argv[8])


def initialize(mode):
    mc = MountainCar(mode)
    s = mc.state_space
    a = mc.action_space
    w = np.zeros((a,s))
    b = 0
    return mc,s,a,w,b

def choose_action(w,state,b,eps,a):
    rand = np.random.random_sample()
    if rand <= eps:
        act = np.random.randint(0,a)
        qsa = (np.matmul(state.T,w[act].T) + b)[0]
    else:
        q_table = []
        for m in range(a):
            q_table.append(np.matmul(state.T,w[m].T) + b)
        act = np.argmax(q_table)
        qsa = q_table[act][0]
    return act,qsa

def find_q_max(s,l,a,w,b):
    new_q_table = []
    newstate = np.zeros((s))
    for j in l[0]:
        newstate[j] = l[0][j]
    newstate = np.reshape(newstate,(-1,1))
    for i in range(a):
        new_q_table.append(np.matmul(newstate.T,w[i].T) + b)
    qmax = max(new_q_table )[0]
    return newstate,qmax

def param_update(w,state,b,lr,qsa,gamma,l,act,qmax):
    w[act] = w[act] - lr*(qsa-(l[1]+(gamma*qmax)))*state.T
    b = b - lr*(qsa-(l[1]+(gamma*qmax)))
    return w,b


def train(mc,w,b,s,a,lr,gamma,eps,episodes,epochs):
    reward = []
    for k in range(episodes):
        state = np.zeros((s))
        state_dict = mc.reset()
        for state_var in state_dict:
            state[state_var] = state_dict[state_var]
        state = np.reshape(state,(-1,1))
        r = 0
        for h in range(epochs):

            action,q_s_a = choose_action(w,state,b,eps,a)
            dictionary = mc.step(action)
            new_state,q_max = find_q_max(s,dictionary,a,w,b)
            
            w,b = param_update(w,state,b,lr,q_s_a,gamma,dictionary,action,q_max)
            r = r + dictionary[1]
            if dictionary[2] != True:
                state = new_state
            else:
                break
        reward.append(r)
    return w,b,reward


mc,state_space,action_space,weights,bias = initialize(mode)
new_weights,new_bias,total_reward = train(mc,weights,bias,state_space,action_space,lr,gamma,epsilon,episodes,max_iter)


with open(returns_out, 'w') as file:
    for i in range(len(total_reward)):
        file.write(str(total_reward[i])+'\n')

with open(weight_out, 'w') as file:
    file.write(str(new_bias)+'\n')
    for i in range(len(new_weights.T.reshape(-1,1))):
        file.write(str(new_weights.T.reshape(-1,1)[i][0])+'\n')

